﻿using System;
using UnityEngine;

namespace GOILevelImporter.Core.Components
{
    [RequireComponent(typeof(Collider2D))]
    public class GravityControlLite : MonoBehaviour
    {
        public Attractors[] gravityWells;
    }
}
