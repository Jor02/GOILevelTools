﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GOILevelImporter.Core.Components
{
    [System.Serializable]
    public class PlayerStart : MonoBehaviour { }
}